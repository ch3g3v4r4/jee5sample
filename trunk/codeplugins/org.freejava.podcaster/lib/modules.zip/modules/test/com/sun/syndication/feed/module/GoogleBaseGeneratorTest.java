/*
 * GoogleBaseGeneratorTest.java
 * JUnit based test
 *
 * Created on November 17, 2005, 3:40 PM
 */

package com.sun.syndication.feed.module;
import com.sun.syndication.feed.module.AbstractTestCase;
import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.SyndFeedOutput;
import com.sun.syndication.feed.module.base.GoogleBase;
import java.io.File;
import junit.framework.*;


/**
 *
 * @author rcooper
 */
public class GoogleBaseGeneratorTest extends AbstractTestCase {
    
    public GoogleBaseGeneratorTest(String testName) {
	super(testName);
    }
    
    public static Test suite() {
	TestSuite suite = new TestSuite(GoogleBaseGeneratorTest.class);
	
	return suite;
    }
    
    
    
    /**
     * Test of generate method, of class com.totsp.xml.syndication.base.io.GoogleBaseGenerator.
     */
    public void testGenerate() throws Exception {
	System.out.println("testGenerate");
	SyndFeedInput input = new SyndFeedInput();
	SyndFeedOutput output = new SyndFeedOutput();
	File testDir = new File(super.getTestFile( "test/base"));
	File[] testFiles = testDir.listFiles();
	for( int h=0; h < testFiles.length; h++){
	    if( !testFiles[h].getName().endsWith(".xml"))
		continue;
	    System.out.println(testFiles[h].getName());
	    SyndFeed feed = input.build(  testFiles[h] );	    
	    output.output( feed, new File( super.getTestFile("target/"+testFiles[h].getName()) ) );
	    SyndFeed feed2 = input.build( new File("target/"+testFiles[h].getName()) );
	    for( int i= 0; i < feed.getEntries().size() ; i++ ){
		SyndEntry entry = (SyndEntry) feed.getEntries().get(i);
		SyndEntry entry2 = (SyndEntry) feed2.getEntries().get(i);
		GoogleBase base = (GoogleBase) entry.getModule( GoogleBase.URI );
		GoogleBase base2 = (GoogleBase) entry2.getModule( GoogleBase.URI );
		this.assertEquals( testFiles[h].getName(), base, base2 );
	    }
	}	
	
    }
}
