BUILD INSTRUCTIONS:

> maven jar 

...will compile and build the jar file. To begin using in your ROME application,
just make sure it is in the classpath.