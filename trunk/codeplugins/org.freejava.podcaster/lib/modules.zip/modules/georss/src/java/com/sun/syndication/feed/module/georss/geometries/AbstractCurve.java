/*
 * Curve.java
 *
 * Created on 8. februar 2007, 10:39
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.syndication.feed.module.georss.geometries;

/**
 * Abstract base class for Curves (linear objects)
 * @author runaas
 */
public abstract class AbstractCurve extends AbstractGeometricPrimitive {
    
    /** Creates a new instance of Curve */
    public AbstractCurve() {
    }
    
}
