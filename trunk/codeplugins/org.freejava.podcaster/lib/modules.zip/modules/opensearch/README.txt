Before using the jar, you should edit the rome.properties file accordingly and place it in your classpath.
To build the jar, use 'ant jar', be sure to edit the build.properties file to specify a lib-dir path to jdom.jar and rome.jar
Example of application usage can be found inside the src/sample directory.