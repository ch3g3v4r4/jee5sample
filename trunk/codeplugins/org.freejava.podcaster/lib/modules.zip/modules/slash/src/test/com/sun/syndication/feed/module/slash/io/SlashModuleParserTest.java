/*
 * SlashModuleParserTest.java
 * JUnit based test
 *
 * Created on November 19, 2005, 9:45 PM
 */

package com.sun.syndication.feed.module.slash.io;
import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.SyndFeedInput;
import junit.framework.*;
import com.sun.syndication.feed.module.slash.AbstractTestCase;
import com.sun.syndication.feed.module.slash.Slash;
import java.io.File;
import java.util.List;
/**
 *
 * @author <a href="mailto:cooper@screaming-penguin.com">Robert "kebernet" Cooper</a>
 */
public class SlashModuleParserTest extends AbstractTestCase {
    
    public SlashModuleParserTest(String testName) {
	super(testName);
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(SlashModuleParserTest.class);
        
        return suite;
    }

    public void testGetNamespaceUri() {
        SlashModuleParser instance = new SlashModuleParser();        
        String result = instance.getNamespaceUri();
        assertEquals(Slash.URI, result);
    }

    public void testQuickParse() throws Exception {
        System.out.println("testParse");
	    SyndFeedInput input = new SyndFeedInput();
	    File testDir = new File(super.getTestFile( "test/xml"));
	    File[] testFiles = testDir.listFiles();
	    for( int h=0; h < testFiles.length; h++){
		if( !testFiles[h].getName().endsWith(".xml"))
		    continue;
		
		SyndFeed feed = input.build(  testFiles[h] );
		List entries = feed.getEntries();
		for( int i=0 ; i< entries.size(); i++ ){
		    SyndEntry entry = (SyndEntry) entries.get(i);
		    System.out.println( entry.getModules().size() );
		    for( int j=0; j < entry.getModules().size() ; j++ ){
			System.out.println( entry.getModules().get(j).getClass() );
			if( entry.getModules().get(j) instanceof Slash ){
			    Slash base = (Slash) entry.getModules().get(j);
			    System.out.println( testFiles[h].getName());
			    System.out.println( super.beanToString( base , false ));
			}
		    }
		}
	    }
    }
    
    public void testSlashdotParse() throws Exception {
        System.out.println("testSlashdotParse");
	SyndFeedInput input = new SyndFeedInput();
	SyndFeed feed = input.build( new File( super.getTestFile("test/xml/slashdot.xml")));
	SyndEntry entry = (SyndEntry) feed.getEntries().get(0);
	Slash module = (Slash) entry.getModule( Slash.URI );
	this.assertEquals("Department", "now-we-need-more-red-dwarf", module.getDepartment());
	this.assertEquals("Section", "mainpage", module.getSection() );
	this.assertEquals("Comments", new Integer(25), module.getComments() );
	this.assertEquals("HitParade", new Integer[]{ new Integer(25), new Integer(22),new Integer(19),new Integer(12), new Integer(2), new Integer(0), new Integer(0) }, 
			    module.getHitParade() );
    }
	
}
