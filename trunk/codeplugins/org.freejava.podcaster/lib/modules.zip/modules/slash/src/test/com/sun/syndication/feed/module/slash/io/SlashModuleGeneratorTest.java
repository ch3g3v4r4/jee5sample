/*
 * SlashModuleGeneratorTest.java
 * JUnit based test
 *
 * Created on November 19, 2005, 10:13 PM
 */

package com.sun.syndication.feed.module.slash.io;

import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.SyndFeedOutput;
import com.sun.syndication.feed.module.slash.AbstractTestCase;
import junit.framework.*;
import com.sun.syndication.feed.module.slash.Slash;
import java.io.File;

/**
 *
 * @author <a href="mailto:cooper@screaming-penguin.com">Robert "kebernet" Cooper</a>
 */
public class SlashModuleGeneratorTest extends AbstractTestCase {
    
    public SlashModuleGeneratorTest(String testName) {
	super(testName);
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(SlashModuleGeneratorTest.class);
        
        return suite;
    }

        /**
     * Test of generate method, of class com.totsp.xml.syndication.base.io.SlashGenerator.
     */
    public void testGenerate() throws Exception {
	System.out.println("testGenerate");
	SyndFeedInput input = new SyndFeedInput();
	SyndFeedOutput output = new SyndFeedOutput();
	File testDir = new File(super.getTestFile( "test/xml"));
	File[] testFiles = testDir.listFiles();
	for( int h=0; h < testFiles.length; h++){
	    if( !testFiles[h].getName().endsWith(".xml"))
		continue;
	    
	    SyndFeed feed = input.build(  testFiles[h] );	    
	    output.output( feed, new File( super.getTestFile("target/"+testFiles[h].getName()) ) );
	    SyndFeed feed2 = input.build( new File("target/"+testFiles[h].getName()) );
	    for( int i= 0; i < feed.getEntries().size() ; i++ ){
		SyndEntry entry = (SyndEntry) feed.getEntries().get(i);
		SyndEntry entry2 = (SyndEntry) feed2.getEntries().get(i);
		Slash slash = (Slash) entry.getModule( Slash.URI );
		Slash slash2 = (Slash) entry2.getModule( Slash.URI );
		this.assertEquals( testFiles[h].getName(), slash, slash2 );
	    }
	}	
	
    }

   
    
}
